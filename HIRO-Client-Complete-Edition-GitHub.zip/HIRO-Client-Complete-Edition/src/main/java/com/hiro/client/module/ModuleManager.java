package com.hiro.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // 1. Combat
        modules.add(new Module("Auto Crystal", "Combat", false));
        modules.add(new Module("Safe Anchor", "Combat", false));
        modules.add(new Module("Sword PvP", "Combat", false));
        modules.add(new Module("Mace PvP", "Combat", false));
        modules.add(new Module("Trigger Bot", "Combat", false));
        modules.add(new Module("Aim Assist", "Combat", false));
        modules.add(new Module("Auto Totem", "Combat", false));
        modules.add(new Module("Criticals Helper", "Combat", false));

        // 2. SMP / Utility
        modules.add(new Module("Auto Builder", "SMP / Utility", false));
        modules.add(new Module("Schematic Builder", "SMP / Utility", false));
        modules.add(new Module("Area Miner", "SMP / Utility", false));
        modules.add(new Module("Auto Ore Miner", "SMP / Utility", false));
        modules.add(new Module("Tree Farmer", "SMP / Utility", false));
        modules.add(new Module("Deep Player Finder", "SMP / Utility", false));
        modules.add(new Module("Base Alert", "SMP / Utility", false));
        modules.add(new Module("Chunk Finder", "SMP / Utility", false));
        modules.add(new Module("Sus Chunk Finder", "SMP / Utility", false));
        modules.add(new Module("Elytra Finder", "SMP / Utility", false));
        modules.add(new Module("Elytra Pilot", "SMP / Utility", false));
        modules.add(new Module("Anchor Hunter", "SMP / Utility", false));
        modules.add(new Module("Auto TPA", "SMP / Utility", false));
        modules.add(new Module("Villager Trader", "SMP / Utility", false));
        modules.add(new Module("Auto Tool", "SMP / Utility", false));
        modules.add(new Module("Fast Place", "SMP / Utility", false));
        modules.add(new Module("Auto Respawn", "SMP / Utility", false));

        // 3. Visuals
        modules.add(new Module("Player ESP", "Visuals", false));
        modules.add(new Module("Storage ESP", "Visuals", false));
        modules.add(new Module("Block ESP", "Visuals", false));
        modules.add(new Module("Spawner ESP", "Visuals", false));
        modules.add(new Module("Hole ESP", "Visuals", false));
        modules.add(new Module("Fullbright", "Visuals", false));
        modules.add(new Module("CustomSky", "Visuals", false));
        modules.add(new Module("Pearl Prediction", "Visuals", false));
        modules.add(new Module("FPS Optimization", "Visuals", true));

        // 4. Movement
        modules.add(new Module("Auto Sprint", "Movement", true));
        modules.add(new Module("Safe Walk", "Movement", false));
        modules.add(new Module("Auto Jump", "Movement", false));
        modules.add(new Module("Auto Spear", "Movement", false));
        modules.add(new Module("No Fall", "Movement", false));

        // 5. Bots
        modules.add(new Module("Crystal PvP Bot", "Bots", false));
        modules.add(new Module("Sword PvP Bot", "Bots", false));
        modules.add(new Module("Mace PvP Bot", "Bots", false));
        modules.add(new Module("Builder Bot", "Bots", false));
        modules.add(new Module("Miner Bot", "Bots", false));
        modules.add(new Module("Tree Farm Bot", "Bots", false));
        modules.add(new Module("Elytra Scout Bot", "Bots", false));
        modules.add(new Module("Trader Bot", "Bots", false));

        // 6. HUD
        modules.add(new Module("Title Bar", "HUD", true));
        modules.add(new Module("Stat Strips", "HUD", true));
        modules.add(new Module("Radar", "HUD", true));
        modules.add(new Module("FPS Graph", "HUD", true));
        modules.add(new Module("Watermark", "HUD", true));
        modules.add(new Module("FPS & Coords", "HUD", true));
        modules.add(new Module("Armor HUD", "HUD", true));
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public List<String> getCategories() {
        List<String> cats = new ArrayList<>();
        for (Module m : modules) {
            if (!cats.contains(m.getCategory())) {
                cats.add(m.getCategory());
            }
        }
        return cats;
    }

    public Module getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public boolean isEnabled(String name) {
        Module m = getByName(name);
        return m != null && m.isEnabled();
    }
}
