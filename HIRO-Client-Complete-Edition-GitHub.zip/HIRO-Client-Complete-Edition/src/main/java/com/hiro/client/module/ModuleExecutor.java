package com.hiro.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

public class ModuleExecutor {
    private final ModuleManager manager;

    public ModuleExecutor(ModuleManager manager) {
        this.manager = manager;
    }

    public void onClientTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            return;
        }

        if (manager.isEnabled("Auto Sprint")) {
            if (mc.player.input.forwardImpulse > 0 && !mc.player.isSprinting() && !mc.player.horizontalCollision) {
                mc.player.setSprinting(true);
            }
        }

        if (manager.isEnabled("Auto Jump")) {
            if (mc.player.onGround() && (mc.player.input.forwardImpulse != 0 || mc.player.input.leftImpulse != 0)) {
                mc.player.jumpFromGround();
            }
        }

        if (manager.isEnabled("Auto Respawn") && mc.screen != null) {
            if (mc.player.isDeadOrDying()) {
                mc.player.respawn();
                mc.setScreen(null);
            }
        }

        if (manager.isEnabled("Trigger Bot") || manager.isEnabled("Sword PvP Bot") || manager.isEnabled("Mace PvP Bot")) {
            HitResult hit = mc.hitResult;
            if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) hit).getEntity();
                if (target instanceof LivingEntity living && living.isAlive() && mc.player.getAttackStrengthScale(0.5f) >= 0.95f) {
                    if (mc.gameMode != null) {
                        mc.gameMode.attack(mc.player, target);
                        mc.player.swing(InteractionHand.MAIN_HAND);
                    }
                }
            }
        }

        if (manager.isEnabled("Aim Assist") || manager.isEnabled("Crystal PvP Bot")) {
            LivingEntity best = findNearestTarget(mc, 6.0);
            if (best != null) {
                double dx = best.getX() - mc.player.getX();
                double dy = (best.getY() + best.getEyeHeight() * 0.75) - mc.player.getEyeY();
                double dz = best.getZ() - mc.player.getZ();
                double horizDist = Math.sqrt(dx * dx + dz * dz);

                float targetYaw = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
                float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, horizDist)));

                mc.player.setYRot(lerpAngle(mc.player.getYRot(), targetYaw, 0.25f));
                mc.player.setXRot(lerpAngle(mc.player.getXRot(), targetPitch, 0.25f));
            }
        }
    }

    private LivingEntity findNearestTarget(Minecraft mc, double maxDist) {
        LivingEntity closest = null;
        double bestSq = maxDist * maxDist;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof LivingEntity living && e != mc.player && living.isAlive()) {
                double dSq = mc.player.distanceToSqr(e);
                if (dSq < bestSq) {
                    bestSq = dSq;
                    closest = living;
                }
            }
        }
        return closest;
    }

    private float lerpAngle(float current, float target, float factor) {
        float diff = ((target - current + 540f) % 360f) - 180f;
        return current + diff * factor;
    }
}
