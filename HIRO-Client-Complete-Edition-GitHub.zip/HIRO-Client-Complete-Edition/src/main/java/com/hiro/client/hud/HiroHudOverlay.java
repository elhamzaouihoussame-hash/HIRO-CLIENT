package com.hiro.client.hud;

import com.hiro.client.HiroClient;
import com.hiro.client.config.ThemeManager.ThemePreset;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayDeque;
import java.util.Deque;

public class HiroHudOverlay implements HudRenderCallback {
    private static final ResourceLocation ICON_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(HiroClient.MOD_ID, "textures/gui/hiro_icon.png");

    private final Deque<Integer> fpsHistory = new ArrayDeque<>();

    @Override
    public void onHudRender(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }

        ThemePreset theme = HiroClient.THEME_MANAGER.getCurrent();
        int currentFps = Math.max(1, mc.getFps());

        if (fpsHistory.size() >= 60) {
            fpsHistory.pollFirst();
        }
        fpsHistory.addLast(currentFps);

        int x = 10;
        int y = 10;

        // Title Bar & Watermark
        if (HiroClient.MODULE_MANAGER.isEnabled("Title Bar") || HiroClient.MODULE_MANAGER.isEnabled("Watermark")) {
            int w = 186;
            int h = 44;
            graphics.fill(x, y, x + w, y + h, theme.panelColor());
            graphics.renderOutline(x, y, w, h, theme.accentColor());
            graphics.blit(ICON_TEXTURE, x + 6, y + 6, 0, 0, 32, 32, 32, 32);

            graphics.drawString(mc.font, "HIRO CLIENT // COMPLETE", x + 44, y + 8, theme.textColor(), true);
            graphics.drawString(mc.font, "Theme: " + theme.name(), x + 44, y + 20, theme.accentColor(), false);
            graphics.drawString(mc.font, "GUI: " + (HiroClient.useDropdownGui ? "Dropdown" : "ClickGUI"), x + 44, y + 31, 0xB8C0D0, false);
            y += h + 6;
        }

        // Stat Strips & FPS/Coords
        if (HiroClient.MODULE_MANAGER.isEnabled("Stat Strips") || HiroClient.MODULE_MANAGER.isEnabled("FPS & Coords")) {
            String coords = String.format("XYZ: %.0f, %.0f, %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            int w = 186;
            int h = 28;
            graphics.fill(x, y, x + w, y + h, theme.panelColor());
            graphics.fill(x, y, x + 3, y + h, theme.accentColor());
            graphics.drawString(mc.font, "FPS: " + currentFps + " | HP: " + String.format("%.1f", mc.player.getHealth()), x + 8, y + 5, theme.textColor(), false);
            graphics.drawString(mc.font, coords, x + 8, y + 16, 0xA8B2C4, false);
            y += h + 6;
        }

        // FPS Graph
        if (HiroClient.MODULE_MANAGER.isEnabled("FPS Graph")) {
            int gw = 120;
            int gh = 34;
            graphics.fill(x, y, x + gw, y + gh, theme.panelColor());
            graphics.renderOutline(x, y, gw, gh, theme.accentColor());
            graphics.drawString(mc.font, "FPS GRAPH (" + currentFps + ")", x + 4, y + 3, theme.textColor(), false);

            int maxFps = 144;
            for (Integer sample : fpsHistory) {
                if (sample > maxFps) maxFps = sample;
            }

            int idx = 0;
            for (Integer sample : fpsHistory) {
                int barH = Math.max(2, (int) ((sample / (float) maxFps) * (gh - 16)));
                int bx = x + 4 + (idx * 2);
                int by = y + gh - 3 - barH;
                graphics.fill(bx, by, bx + 1, y + gh - 3, theme.accentColor());
                idx++;
            }
            y += gh + 6;
        }

        // Radar
        if (HiroClient.MODULE_MANAGER.isEnabled("Radar") && mc.level != null) {
            int size = 68;
            int rx = mc.getWindow().getGuiScaledWidth() - size - 10;
            int ry = 10;
            int cx = rx + size / 2;
            int cy = ry + size / 2;

            graphics.fill(rx, ry, rx + size, ry + size, theme.panelColor());
            graphics.renderOutline(rx, ry, size, size, theme.accentColor());
            graphics.fill(cx - 1, ry + 2, cx + 2, ry + size - 2, 0x33FFFFFF);
            graphics.fill(rx + 2, cy - 1, rx + size - 2, cy + 2, 0x33FFFFFF);
            graphics.fill(cx - 2, cy - 2, cx + 2, cy + 2, theme.accentColor());

            double range = 64.0;
            for (Entity entity : mc.level.entitiesForRendering()) {
                if (entity == mc.player) continue;
                double dx = (entity.getX() - mc.player.getX()) / range;
                double dz = (entity.getZ() - mc.player.getZ()) / range;
                double dist = Math.hypot(dx, dz);
                if (dist <= 1.0) {
                    int px = cx + (int) (dx * (size / 2.0 - 4));
                    int py = cy + (int) (dz * (size / 2.0 - 4));
                    int dotColor = (entity instanceof Player) ? 0xFFFF4444 : 0xFF66D9EF;
                    graphics.fill(px - 1, py - 1, px + 2, py + 2, dotColor);
                }
            }
            graphics.drawString(mc.font, "RADAR", rx + 4, ry + size - 11, theme.textColor(), false);
        }
    }
}
