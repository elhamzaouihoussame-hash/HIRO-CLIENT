package com.hiro.client.config;

import java.util.List;

public class ThemeManager {
    public record ThemePreset(String name, int bgColor, int panelColor, int accentColor, int textColor) {}

    private static final List<ThemePreset> PRESETS = List.of(
            new ThemePreset("HIRO Noir", 0x99000000, 0xEE121216, 0xFFFFFFFF, 0xFFFFFFFF),
            new ThemePreset("Crimson Eclipse", 0x99080406, 0xEE1B0D12, 0xFFFF3B5C, 0xFFF5F5F7),
            new ThemePreset("Cyber Cyan", 0x99030A10, 0xEE0A1622, 0xFF00E5FF, 0xFFEAF8FF),
            new ThemePreset("Emerald SMP", 0x99040D08, 0xEE0C1C14, 0xFF2EE58A, 0xFFECFFF5)
    );

    private int activeIndex = 0;

    public ThemePreset getCurrent() {
        return PRESETS.get(activeIndex);
    }

    public void nextTheme() {
        activeIndex = (activeIndex + 1) % PRESETS.size();
    }

    public List<ThemePreset> getPresets() {
        return PRESETS;
    }
}
