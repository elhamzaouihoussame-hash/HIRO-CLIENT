package com.hiro.client;

import com.hiro.client.config.ThemeManager;
import com.hiro.client.gui.HiroClickGuiScreen;
import com.hiro.client.hud.HiroHudOverlay;
import com.hiro.client.module.ModuleExecutor;
import com.hiro.client.module.ModuleManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HiroClient implements ClientModInitializer {
    public static final String MOD_ID = "hiroclient";
    public static final Logger LOGGER = LoggerFactory.getLogger("HIRO Client");
    public static final ModuleManager MODULE_MANAGER = new ModuleManager();
    public static final ModuleExecutor MODULE_EXECUTOR = new ModuleExecutor(MODULE_MANAGER);
    public static final ThemeManager THEME_MANAGER = new ThemeManager();

    public static boolean useDropdownGui = false;
    private static KeyMapping openGuiKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing HIRO Client Complete Edition...");

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.hiroclient.open_gui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.hiroclient.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new HiroClickGuiScreen());
                }
            }

            MODULE_EXECUTOR.onClientTick(Minecraft.getInstance());
        });

        HudRenderCallback.EVENT.register(new HiroHudOverlay());
    }
}
