package com.hiro.client.gui;

import com.hiro.client.HiroClient;
import com.hiro.client.config.ThemeManager.ThemePreset;
import com.hiro.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class HiroClickGuiScreen extends Screen {
    private String selectedCategory = "Combat";
    private int scrollOffset = 0;

    public HiroClickGuiScreen() {
        super(Component.literal("HIRO Client"));
    }

    @Override
    protected void init() {
        ThemePreset theme = HiroClient.THEME_MANAGER.getCurrent();
        List<String> categories = HiroClient.MODULE_MANAGER.getCategories();

        int catW = 74;
        int totalCatW = categories.size() * (catW + 3);
        int startCatX = Math.max(8, (this.width - totalCatW) / 2);

        for (int i = 0; i < categories.size(); i++) {
            String cat = categories.get(i);
            int bx = startCatX + i * (catW + 3);
            this.addRenderableWidget(Button.builder(Component.literal(cat), btn -> {
                this.selectedCategory = cat;
                this.scrollOffset = 0;
                this.rebuildWidgets();
            }).bounds(bx, 28, catW, 18).build());
        }

        // Mode & Theme Switchers
        this.addRenderableWidget(Button.builder(
                Component.literal("GUI: " + (HiroClient.useDropdownGui ? "Dropdown" : "ClickGUI")),
                btn -> {
                    HiroClient.useDropdownGui = !HiroClient.useDropdownGui;
                    this.rebuildWidgets();
                }).bounds(10, this.height - 28, 110, 18).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Theme: " + theme.name()),
                btn -> {
                    HiroClient.THEME_MANAGER.nextTheme();
                    this.rebuildWidgets();
                }).bounds(this.width - 140, this.height - 28, 130, 18).build());

        if (HiroClient.useDropdownGui) {
            buildDropdownColumns(categories);
        } else {
            buildSingleCategoryList();
        }
    }

    private void buildSingleCategoryList() {
        List<Module> filtered = new ArrayList<>();
        for (Module m : HiroClient.MODULE_MANAGER.getModules()) {
            if (m.getCategory().equals(selectedCategory)) {
                filtered.add(m);
            }
        }

        int modX = this.width / 2 - 125;
        int modY = 54;
        int maxRows = Math.max(4, (this.height - 92) / 22);

        int start = Math.min(scrollOffset, Math.max(0, filtered.size() - maxRows));
        int end = Math.min(filtered.size(), start + maxRows);

        int row = 0;
        for (int i = start; i < end; i++) {
            Module m = filtered.get(i);
            String label = m.getName() + " : " + (m.isEnabled() ? "ON" : "OFF");
            this.addRenderableWidget(Button.builder(Component.literal(label), btn -> {
                m.toggle();
                this.rebuildWidgets();
            }).bounds(modX, modY + row * 22, 250, 19).build());
            row++;
        }
    }

    private void buildDropdownColumns(List<String> categories) {
        int cols = Math.min(3, categories.size());
        int colW = Math.min(145, (this.width - 24) / cols);
        int startX = (this.width - (cols * (colW + 4))) / 2;
        int startY = 54;

        for (int c = 0; c < categories.size(); c++) {
            String cat = categories.get(c);
            int colIndex = c % cols;
            int rowBlock = c / cols;
            int x = startX + colIndex * (colW + 4);
            int y = startY + rowBlock * 120;

            int itemRow = 0;
            for (Module m : HiroClient.MODULE_MANAGER.getModules()) {
                if (m.getCategory().equals(cat) && itemRow < 4) {
                    String shortLabel = m.getName() + " [" + (m.isEnabled() ? "ON" : "OFF") + "]";
                    this.addRenderableWidget(Button.builder(Component.literal(shortLabel), btn -> {
                        m.toggle();
                        this.rebuildWidgets();
                    }).bounds(x, y + 14 + itemRow * 18, colW, 16).build());
                    itemRow++;
                }
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!HiroClient.useDropdownGui) {
            if (scrollY < 0) scrollOffset++;
            if (scrollY > 0) scrollOffset = Math.max(0, scrollOffset - 1);
            this.rebuildWidgets();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        ThemePreset theme = HiroClient.THEME_MANAGER.getCurrent();
        graphics.fill(0, 0, this.width, this.height, theme.bgColor());
        graphics.drawCenteredString(
                this.font,
                "HIRO CLIENT // " + (HiroClient.useDropdownGui ? "DROPDOWN GUI" : selectedCategory.toUpperCase()),
                this.width / 2,
                12,
                theme.textColor()
        );
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
